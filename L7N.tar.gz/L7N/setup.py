import setuptools
setuptools.setup(
    name='L7N',
    version='0.1',
    author='Programmer L7N - Fahal ',
    description='Module By @g_4_q In telegram ',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License"
    ]
)